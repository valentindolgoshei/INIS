document.addEventListener('DOMContentLoaded', function() { // Запустим код когда отрисуется код страницы

	var products = document.querySelector('.products'); // блок продуктов
	

	if(products) { // Если есть блок продуктов
		if(shirts.length > 0) { // Если есть записи о товарах
			for(var id = 0; id < shirts.length; id++) { // Проходим по всем доступным записям
				var item = shirts[id]; // получаем текущую запись

				// создаём элемент карточки товара
				var card = document.createElement('div');
				card.classList.add('products-item');

				// добавляем картинки в карточку
				var images = document.createElement('div'); // Создаём блок под картинки
				images.classList.add('image'); // Добавляем класс

				var image = document.createElement('img'); // Создаём картинку
				image.classList.add('image-front'); // Добавляем класс
				image.src = item.default.front; // Добавляем ссылку на картинку
				image.alt = item.name; // Добавляем альтернативный текст
				images.append(image); // ДОбавляем картинку в блок

				// Повторяем для картинки back
				image = document.createElement('img'); // Создаём картинку
				image.classList.add('image-back'); // Добавляем класс
				image.src = item.default.back; // Добавляем ссылку на картинку
				image.alt = item.name; // Добавляем альтернативный текст
				images.append(image); // ДОбавляем картинку в блок
				card.append(images); // Добавляем в карточку
				
				// Добавляем количество подписей
				var colors = Object.keys(item.colors).length; // получаем количество досутпных цветов
				var colorsText = 'цветах'; // склонение
				if(colors == 1) {
					colorsText = 'цвете';
				}
				var options = document.createElement('div'); // Создаём элемент
				options.classList.add('options'); // Добавляем класс
				options.innerHTML = 'Доступен в '+colors+' '+colorsText; // Добавляем текст
				card.append(options); // Добавляем в карточку

				// Добавляем кнопки
				var links = document.createElement('div'); // Создаём элемент
				links.classList.add('links'); // Добавляем класс

				

				link = document.createElement('a'); // Создаём ссылку
				link.classList.add('links-item'); // Добавляем класс
				link.href = './details.html'; // Добавляем ссылку на страницу
				link.search = 'id='+id; // Добавляем параметр к ссылке
				link.innerHTML = 'See page'; // Добавляем название ссылки
				links.append(link); // Добавляем ссылку к блоку

				card.append(links); // Добавляем блок к карточке

				// добавляем созданную карточку в список товаров
				products.append(card);
			}
		} else { // Если продуктов нет
			var empty = document.createElement('div'); // создаём блок
			empty.classList.add('products-empty'); // Добавляем класс
			empty.innerHTML = 'Продуктов нет'; // Пишем, что продуктов нету
			products.append(empty); // Добавляем в блок под продукты
		}
		
		// Выводим информацию в модальное окно по IDу товара
		function quickView(e) {
			var id = +e.target.getAttribute('data-id'); // Получаем ID товара из атрибута
			var item = shirts[id]; // Получаем информацию по IDу
			var content = modal.querySelector('.modal-content'); // Получаем контент модального окна

			content.innerHTML = ''; // Очищаем его от старых записей

			// Блок с картинками
			var images = document.createElement('div'); // Создаём блок под картинки
			images.classList.add('image'); // Добавляем класс

			// Блок с картинкой "вид спереди"
			var imageBlock = document.createElement('div'); // Создаём блок с картинко
			imageBlock.classList.add('image-front'); // Добавляем класс

			var image = document.createElement('img'); // Создаём картинку
			image.src = item.default.front; // Добавляем ссылку на картинку
			image.alt = item.name; // Добавляем альтернативный текст
			imageBlock.append(image); // ДОбавляем картинку в блок

			var text = document.createElement('p'); // Создаём блок текста
			text.innerHTML = 'Front side'; // Добавляем текст
			imageBlock.append(text); // Добавляем блок к блоку с картинкой

			images.append(imageBlock); // Добавляем блок с картинкой 

			// Блок с картинкой "вид сзади"
			imageBlock = document.createElement('div'); // Создаём блок с картинко
			imageBlock.classList.add('image-front'); // Добавляем класс

			image = document.createElement('img'); // Создаём картинку
			image.src = item.default.back; // Добавляем ссылку на картинку
			image.alt = item.name; // Добавляем альтернативный текст
			imageBlock.append(image); // ДОбавляем картинку в блок

			text = document.createElement('p'); // Создаём блок текста
			text.innerHTML = 'Back side'; // Добавляем текст
			imageBlock.append(text); // Добавляем блок к блоку с картинкой

			images.append(imageBlock); // Добавляем блок с картинкой 

			content.append(images); // Добавляем блок с картинками в контент

			// Блок с информацией
			var info = document.createElement('div'); // Создаём блок под информацию
			info.classList.add('info'); // Добавляем класс

			// Блок с заголовком
			var title = document.createElement('h2'); // Создаём заголовок
			title.classList.add('title'); // Добавляем класс
			title.innerHTML = item.name; // Добавляем заголовок
			info.append(title); // Добавляем в информацию

			// Блок с описанием
			var description = document.createElement('p'); // Создаём блок под описание
			description.classList.add('description'); // Добавляем класс
			description.innerHTML = item.description; // Добавляем описание
			info.append(description); // Добавляем в информацию

			// Блок с параметрами (цветами)
			if(item.colors) { // Если есть цвета
				var options = document.createElement('div'); // Создаём блок под описание
				options.classList.add('options'); // Добавляем класс
				
				for(var color in item.colors) { // Проходим циклом по цветам
					var option = document.createElement('a'); // Созадём ссылку
					option.classList.add('options-item'); // Добавляем класс
					option.style.setProperty('--option-color', color); // Добавляем CSS переменную с цветом
					option.href = './details.html'; // Добавляем ссыку на страницу
					option.search = 'id='+id+'&color='+color; // Добавляем параметры
					option.innerHTML = color; // Добавляем название цвета
					options.append(option); // Добавляем ссылку в блок с параметрами
				}

				info.append(options); // Добавляем в информацию
			}

			// Блок с ценой
			var price = document.createElement('p'); // Создаём блок под цену
			price.classList.add('price'); // Добавляем класс
			price.innerHTML = item.price; // Добавляем цену
			info.append(price); // Добавляем в информацию

			content.append(info); // Добавляем информацию в контент

			modal.querySelector('.modal-goto').search = 'id='+id; // Добавляем кнопке "Перейти к товару" параметр

			// Отображаем модальное окно
			document.body.style.overflow = 'hidden'; // Отключаем возможность управление скроллом у сайта
			modal.style.display = ''; // Отображаем модалку
		}

		// Закртие модального окна
		modal.querySelector('.modal-close').addEventListener('click', function() {
			document.body.style.overflow = ''; // Возвращаем возможность управление скроллом сайта
			modal.style.display = 'none'; // Скрываем отображение модалки
		}, false);
	}

	// Отображение детальной информации товара
	var details = document.querySelector('.details');

	if(details) {
		var search = location.search; // Получаем параметры из ссылки
		search = search.slice(1); // Удаляем знак "?" вначале строки
		search = search.split('&'); // Разбиваем строку на массив по знаку "&"
		var param = {}; // Создаём объект для хранения параметром
		for(var i = 0; i < search.length; i++) { // Проходим циклом по массиву "search"
			var temp = search[i]; // Получаем строку из массива
			temp = temp.split('='); // Разбиваем строку по знаку "="
			param[temp[0]] = temp[1]; // Сохранаем ключ и значение в переменную "param"
		}
		
		// Получаем товар из запроса
		var item = shirts[param.id];

		// Создаём разметку товара

		// Создаём картинку
		var images = document.createElement('div');
		images.classList.add('images');

		// Блок с картинкой "вид спереди"
		var imageBlock = document.createElement('div'); // Создаём блок с картинко
		imageBlock.classList.add('image-front'); // Добавляем класс

		var image = document.createElement('img'); // Создаём картинку
		if(param.color) { // Если в запросе есть цвет
			image.src = item.colors[param.color].front; // Добавляем ссылку на картинку с цветом
		} else {
			image.src = item.default.front; // Добавляем ссылку на картинку
		}
		image.alt = item.name; // Добавляем альтернативный текст
		imageBlock.append(image); // ДОбавляем картинку в блок

		var text = document.createElement('p'); // Создаём блок текста
		text.innerHTML = 'Front side'; // Добавляем текст
		imageBlock.append(text); // Добавляем блок к блоку с картинкой

		images.append(imageBlock); // Добавляем блок с картинкой

		// Блок с картинкой "вид сзади"
		imageBlock = document.createElement('div'); // Создаём блок с картинко
		imageBlock.classList.add('image-back'); // Добавляем класс

		image = document.createElement('img'); // Создаём картинку
		if(param.color) { // Если в запросе есть цвет
			image.src = item.colors[param.color].back; // Добавляем ссылку на картинку с цветом
		} else {
			image.src = item.default.back; // Добавляем ссылку на картинку
		}
		image.alt = item.name; // Добавляем альтернативный текст
		imageBlock.append(image); // ДОбавляем картинку в блок

		text = document.createElement('p'); // Создаём блок текста
		text.innerHTML = 'Back side'; // Добавляем текст
		imageBlock.append(text); // Добавляем блок к блоку с картинкой

		images.append(imageBlock); // Добавляем блок с картинкой

		details.append(images); // Добавляем картинки в блок

		// Блок с информацией
		var info = document.createElement('div'); // Создаём блок под информацию
		info.classList.add('info'); // Добавляем класс

		// Блок с заголовком
		var title = document.createElement('h2'); // Создаём заголовок
		title.classList.add('title'); // Добавляем класс
		title.innerHTML = item.name; // Добавляем заголовок
		info.append(title); // Добавляем в информацию

		// Блок с описанием
		var description = document.createElement('p'); // Создаём блок под описание
		description.classList.add('description'); // Добавляем класс
		description.innerHTML = item.description; // Добавляем описание
		info.append(description); // Добавляем в информацию

		// Блок с параметрами (цветами)
		if(item.colors) { // Если есть цвета
			var options = document.createElement('div'); // Создаём блок под описание
			options.classList.add('options'); // Добавляем класс
			
			for(var color in item.colors) { // Проходим циклом по цветам
				if(color == param.color) { // Если параметр цвета в запросе совпадает с цветом опции, то выделяем как "выбранный"
					var option = document.createElement('span'); // Созадём span
					option.classList.add('selected'); // Добавляем класс
				} else { // Если не совпадает, то добавляем как ссылку
					var option = document.createElement('a'); // Созадём ссылку
					option.href = './details.html'; // Добавляем ссыку на страницу
					option.search = 'id='+param.id+'&color='+color; // Добавляем параметры
				}
				option.classList.add('options-item'); // Добавляем класс
				option.style.setProperty('--option-color', color); // Добавляем CSS переменную с цветом
				option.innerHTML = color; // Добавляем название цвета
				options.append(option); // Добавляем ссылку в блок с параметрами
			}

			info.append(options); // Добавляем в информацию
		}

		// Блок с ценой
		var price = document.createElement('p'); // Создаём блок под цену
		price.classList.add('price'); // Добавляем класс
		price.innerHTML = item.price; // Добавляем цену
		info.append(price); // Добавляем в информацию

		details.append(info); // Добавляем информацию в контент
	}
});